#ifndef _BOOTLOADER_H_
#define _BOOTLOADER_H_

void bootloader_main(unsigned long address);
unsigned int get_kernel_size(void);

#endif